"""
app.py
------
Flask front-end for the Log Analysis & Suspicious Activity Detector.

Routes:
  GET  /            Dashboard: summary stats + recent alerts
  GET  /logs        Browse raw parsed log entries
  GET  /alerts      Browse all detected alerts
  POST /regenerate  Generate a fresh batch of demo logs and re-run detection
"""

import os
from flask import Flask, render_template, redirect, url_for, flash

import database
from log_generator import generate_log_file
from analyzer import parse_log_file, run_all_detectors

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-me"

LOG_PATH = "data/server.log"

SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


def run_pipeline():
    """Generate demo logs, parse them, run detectors, persist everything."""
    os.makedirs("data", exist_ok=True)
    database.init_db()
    database.clear_all()

    generate_log_file(path=LOG_PATH, days=5, normal_lines=400)
    df = parse_log_file(LOG_PATH)

    log_df = df.rename(columns={"username": "username"})[["timestamp", "ip", "username", "event", "reason"]].copy()
    log_df["timestamp"] = log_df["timestamp"].astype(str)
    database.insert_logs(log_df)

    alerts = run_all_detectors(df)
    if alerts:
        database.insert_alerts(alerts)

    return len(df), len(alerts)


@app.route("/")
def dashboard():
    stats = database.summary_stats()
    alerts = database.fetch_alerts(limit=15)
    for a in alerts:
        a["rank"] = SEVERITY_ORDER.get(a["severity"], 3)
    return render_template("dashboard.html", stats=stats, alerts=alerts)


@app.route("/logs")
def logs_view():
    logs = database.fetch_logs(limit=500)
    return render_template("logs.html", logs=logs)


@app.route("/alerts")
def alerts_view():
    alerts = database.fetch_alerts(limit=500)
    return render_template("alerts.html", alerts=alerts)


@app.route("/regenerate", methods=["POST"])
def regenerate():
    total_logs, total_alerts = run_pipeline()
    flash(f"Generated {total_logs} log lines and found {total_alerts} suspicious events.")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    # Make sure there's data on first run
    if not os.path.exists(database.DB_PATH):
        run_pipeline()
    else:
        database.init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
