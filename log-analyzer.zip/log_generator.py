"""
log_generator.py
-----------------
Generates a realistic synthetic server/auth log file for demo purposes.

The log format mimics a simplified auth log:
    2026-09-04 03:14:22 | 203.0.113.7 | jsmith | LOGIN_FAILED | reason=bad_password
    2026-09-04 03:14:25 | 203.0.113.7 | jsmith | LOGIN_FAILED | reason=bad_password
    2026-09-04 09:02:11 | 10.0.0.15   | jsmith | LOGIN_SUCCESS | reason=-

Normal traffic is generated first, then several suspicious patterns are
deliberately injected so the analyzer has real things to detect:

  1. Brute-force: one IP hammering LOGIN_FAILED against a single user.
  2. Credential stuffing: one IP trying many different usernames.
  3. Impossible travel / unusual IP: a user who normally logs in from a
     known IP suddenly logs in successfully from a brand-new, unseen IP.
  4. Off-hours access: successful logins in the middle of the night for
     users who normally only log in during business hours.
"""

import random
from datetime import datetime, timedelta

USERS = ["jsmith", "agarcia", "mchen", "rpatel", "kwilliams",
         "tnguyen", "svolkov", "admin", "dlee", "bthompson"]

# "Known" / trusted IPs each user normally logs in from (internal network)
KNOWN_IPS = {
    user: f"10.0.{random.randint(0, 5)}.{random.randint(2, 254)}"
    for user in USERS
}

SUSPICIOUS_EXTERNAL_IPS = [
    "203.0.113.7", "198.51.100.23", "185.220.101.4",
    "45.155.205.13", "91.240.118.172", "23.129.64.150",
]

EVENT_REASONS = {
    "LOGIN_SUCCESS": "-",
    "LOGIN_FAILED": "bad_password",
    "LOGIN_LOCKED": "account_locked_too_many_attempts",
}


def _fmt(ts, ip, user, event, reason):
    return f"{ts.strftime('%Y-%m-%d %H:%M:%S')} | {ip:15s} | {user:12s} | {event:14s} | reason={reason}"


def generate_normal_traffic(start, hours, lines):
    """Everyday, boring, mostly-successful logins during business hours."""
    entries = []
    for _ in range(lines):
        user = random.choice(USERS)
        ip = KNOWN_IPS[user]
        # business hours: 8am - 7pm
        day_offset = random.randint(0, hours // 24)
        hour = random.randint(8, 19)
        minute = random.randint(0, 59)
        second = random.randint(0, 59)
        ts = start + timedelta(days=day_offset, hours=hour - start.hour,
                                minutes=minute, seconds=second)
        event = "LOGIN_SUCCESS" if random.random() > 0.05 else "LOGIN_FAILED"
        entries.append(_fmt(ts, ip, user, event, EVENT_REASONS[event]))
    return entries


def generate_brute_force(start):
    """One external IP hammers a single user account with failed logins."""
    entries = []
    target_user = "admin"
    attacker_ip = random.choice(SUSPICIOUS_EXTERNAL_IPS)
    base = start + timedelta(hours=random.randint(0, 6), minutes=random.randint(0, 59))
    for i in range(22):
        ts = base + timedelta(seconds=i * random.randint(2, 8))
        entries.append(_fmt(ts, attacker_ip, target_user, "LOGIN_FAILED", "bad_password"))
    # eventually locks
    entries.append(_fmt(base + timedelta(seconds=200), attacker_ip, target_user,
                         "LOGIN_LOCKED", EVENT_REASONS["LOGIN_LOCKED"]))
    return entries


def generate_credential_stuffing(start):
    """One external IP tries many different usernames in a short burst."""
    entries = []
    attacker_ip = random.choice(SUSPICIOUS_EXTERNAL_IPS)
    base = start + timedelta(days=random.randint(1, 3), hours=random.randint(1, 5))
    tried_users = random.sample(USERS, 7)
    for i, user in enumerate(tried_users):
        ts = base + timedelta(seconds=i * random.randint(3, 10))
        entries.append(_fmt(ts, attacker_ip, user, "LOGIN_FAILED", "bad_password"))
    return entries


def generate_unusual_ip_success(start):
    """A normally well-behaved user logs in successfully from a brand-new IP."""
    entries = []
    user = random.choice(USERS)
    new_ip = random.choice(SUSPICIOUS_EXTERNAL_IPS)
    ts = start + timedelta(days=random.randint(1, 4), hours=random.randint(9, 17))
    entries.append(_fmt(ts, new_ip, user, "LOGIN_SUCCESS", "-"))
    return entries


def generate_off_hours_access(start):
    """A successful login at 2-4am for a user who never logs in that late."""
    entries = []
    user = random.choice(USERS)
    ip = KNOWN_IPS[user]
    ts = start + timedelta(days=random.randint(0, 4),
                            hours=random.choice([2, 3, 4]),
                            minutes=random.randint(0, 59))
    entries.append(_fmt(ts, ip, user, "LOGIN_SUCCESS", "-"))
    return entries


def generate_log_file(path="data/server.log", days=5, normal_lines=400, seed=None):
    if seed is not None:
        random.seed(seed)

    start = datetime.now() - timedelta(days=days)

    entries = []
    entries += generate_normal_traffic(start, hours=days * 24, lines=normal_lines)
    entries += generate_brute_force(start)
    entries += generate_credential_stuffing(start)
    entries += generate_unusual_ip_success(start)
    entries += generate_unusual_ip_success(start)
    entries += generate_off_hours_access(start)
    entries += generate_off_hours_access(start)

    # sort chronologically, like a real log file
    def parse_ts(line):
        return datetime.strptime(line.split(" | ")[0], "%Y-%m-%d %H:%M:%S")

    entries.sort(key=parse_ts)

    with open(path, "w") as f:
        f.write("\n".join(entries) + "\n")

    return path, len(entries)


if __name__ == "__main__":
    path, count = generate_log_file()
    print(f"Generated {count} log lines -> {path}")
