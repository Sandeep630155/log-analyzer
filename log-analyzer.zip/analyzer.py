"""
analyzer.py
-----------
Parses the raw log file into a pandas DataFrame and runs a set of
detection rules over it to flag suspicious activity.

Detection rules:
  1. BRUTE_FORCE          - >= N failed logins from the same IP against
                             the same user within a rolling time window.
  2. CREDENTIAL_STUFFING  - one IP attempting logins against many distinct
                             usernames within a short window.
  3. UNUSUAL_IP_SUCCESS   - a successful login from an IP never seen before
                             for that user (based on the user's historical
                             known IPs within this log set).
  4. OFF_HOURS_ACCESS     - a successful login between midnight and 5am.
  5. ACCOUNT_LOCKOUT      - a LOGIN_LOCKED event (always high severity).
"""

import pandas as pd

LOG_COLUMNS = ["timestamp", "ip", "username", "event", "reason"]

BRUTE_FORCE_THRESHOLD = 5          # failed logins
BRUTE_FORCE_WINDOW_MIN = 10        # minutes
STUFFING_DISTINCT_USER_THRESHOLD = 4
STUFFING_WINDOW_MIN = 15
OFF_HOURS_START, OFF_HOURS_END = 0, 5  # 12am - 5am


def parse_log_file(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) != 5:
                continue
            ts, ip, user, event, reason = parts
            reason = reason.replace("reason=", "")
            rows.append([ts, ip, user, event, reason])

    df = pd.DataFrame(rows, columns=LOG_COLUMNS)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df.sort_values("timestamp").reset_index(drop=True)


def _mk_alert(ts, ip, username, rule, severity, description):
    return {
        "timestamp": str(ts),
        "ip": ip,
        "username": username,
        "rule": rule,
        "severity": severity,
        "description": description,
    }


def detect_brute_force(df):
    alerts = []
    failed = df[df["event"] == "LOGIN_FAILED"].copy()
    for (ip, user), group in failed.groupby(["ip", "username"]):
        group = group.sort_values("timestamp")
        times = group["timestamp"].tolist()
        window = []
        already_alerted = False
        for t in times:
            window.append(t)
            window = [w for w in window if (t - w).total_seconds() <= BRUTE_FORCE_WINDOW_MIN * 60]
            if len(window) >= BRUTE_FORCE_THRESHOLD and not already_alerted:
                alerts.append(_mk_alert(
                    t, ip, user, "BRUTE_FORCE", "HIGH",
                    f"{len(window)} failed logins for user '{user}' from {ip} "
                    f"within {BRUTE_FORCE_WINDOW_MIN} minutes."
                ))
                already_alerted = True  # one alert per burst is enough for the demo
    return alerts


def detect_credential_stuffing(df):
    alerts = []
    failed = df[df["event"] == "LOGIN_FAILED"].copy()
    for ip, group in failed.groupby("ip"):
        group = group.sort_values("timestamp")
        rows = group.to_dict("records")
        window = []
        for row in rows:
            window.append(row)
            window = [w for w in window
                      if (row["timestamp"] - w["timestamp"]).total_seconds() <= STUFFING_WINDOW_MIN * 60]
            distinct_users = {w["username"] for w in window}
            if len(distinct_users) >= STUFFING_DISTINCT_USER_THRESHOLD:
                alerts.append(_mk_alert(
                    row["timestamp"], ip, None, "CREDENTIAL_STUFFING", "HIGH",
                    f"IP {ip} attempted logins against {len(distinct_users)} distinct "
                    f"usernames within {STUFFING_WINDOW_MIN} minutes: "
                    f"{', '.join(sorted(distinct_users))}."
                ))
                window = []
    return alerts


def detect_unusual_ip(df):
    alerts = []
    successes = df[df["event"] == "LOGIN_SUCCESS"].sort_values("timestamp")
    seen_ips_per_user = {}
    for row in successes.to_dict("records"):
        user, ip, ts = row["username"], row["ip"], row["timestamp"]
        seen = seen_ips_per_user.setdefault(user, set())
        if seen and ip not in seen:
            alerts.append(_mk_alert(
                ts, ip, user, "UNUSUAL_IP_SUCCESS", "MEDIUM",
                f"User '{user}' logged in successfully from a new/unseen IP {ip} "
                f"(previously seen from: {', '.join(sorted(seen))})."
            ))
        seen.add(ip)
    return alerts


def detect_off_hours(df):
    alerts = []
    successes = df[df["event"] == "LOGIN_SUCCESS"].copy()
    successes["hour"] = successes["timestamp"].dt.hour
    off_hours = successes[(successes["hour"] >= OFF_HOURS_START) & (successes["hour"] < OFF_HOURS_END)]
    for row in off_hours.to_dict("records"):
        alerts.append(_mk_alert(
            row["timestamp"], row["ip"], row["username"], "OFF_HOURS_ACCESS", "LOW",
            f"User '{row['username']}' logged in at {row['timestamp'].strftime('%H:%M')} "
            f"(outside normal business hours) from {row['ip']}."
        ))
    return alerts


def detect_lockouts(df):
    alerts = []
    locked = df[df["event"] == "LOGIN_LOCKED"]
    for row in locked.to_dict("records"):
        alerts.append(_mk_alert(
            row["timestamp"], row["ip"], row["username"], "ACCOUNT_LOCKOUT", "HIGH",
            f"Account '{row['username']}' was locked out after repeated failed "
            f"attempts from {row['ip']}."
        ))
    return alerts


def run_all_detectors(df):
    alerts = []
    alerts += detect_brute_force(df)
    alerts += detect_credential_stuffing(df)
    alerts += detect_unusual_ip(df)
    alerts += detect_off_hours(df)
    alerts += detect_lockouts(df)
    alerts.sort(key=lambda a: a["timestamp"], reverse=True)
    return alerts
