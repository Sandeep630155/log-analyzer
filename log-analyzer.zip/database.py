"""
database.py
------------
Thin SQLite persistence layer.

Two tables:
  logs   - every parsed log line
  alerts - suspicious activity findings produced by analyzer.py
"""

import sqlite3
from contextlib import contextmanager

DB_PATH = "data/activity.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    ip          TEXT NOT NULL,
    username    TEXT NOT NULL,
    event       TEXT NOT NULL,
    reason      TEXT
);

CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    ip          TEXT,
    username    TEXT,
    rule        TEXT NOT NULL,
    severity    TEXT NOT NULL,
    description TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_logs_ip ON logs(ip);
CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(username);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)


def clear_all():
    with get_conn() as conn:
        conn.execute("DELETE FROM logs")
        conn.execute("DELETE FROM alerts")


def insert_logs(df):
    """Bulk-insert a pandas DataFrame of parsed log rows."""
    with get_conn() as conn:
        df.to_sql("logs", conn, if_exists="append", index=False)


def insert_alerts(alerts):
    """alerts: list of dicts with keys timestamp, ip, username, rule, severity, description"""
    with get_conn() as conn:
        conn.executemany(
            """INSERT INTO alerts (timestamp, ip, username, rule, severity, description)
               VALUES (:timestamp, :ip, :username, :rule, :severity, :description)""",
            alerts,
        )


def fetch_alerts(limit=200):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM alerts ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def fetch_logs(limit=500):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM logs ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def summary_stats():
    with get_conn() as conn:
        total_logs = conn.execute("SELECT COUNT(*) c FROM logs").fetchone()["c"]
        total_alerts = conn.execute("SELECT COUNT(*) c FROM alerts").fetchone()["c"]
        failed_logins = conn.execute(
            "SELECT COUNT(*) c FROM logs WHERE event='LOGIN_FAILED'"
        ).fetchone()["c"]
        by_severity = conn.execute(
            "SELECT severity, COUNT(*) c FROM alerts GROUP BY severity"
        ).fetchall()
        unique_ips = conn.execute("SELECT COUNT(DISTINCT ip) c FROM logs").fetchone()["c"]
        return {
            "total_logs": total_logs,
            "total_alerts": total_alerts,
            "failed_logins": failed_logins,
            "unique_ips": unique_ips,
            "by_severity": {r["severity"]: r["c"] for r in by_severity},
        }
